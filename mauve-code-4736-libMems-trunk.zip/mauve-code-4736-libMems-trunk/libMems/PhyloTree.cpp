#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "PhyloTree.h"
using namespace std;

typedef unsigned uint;

