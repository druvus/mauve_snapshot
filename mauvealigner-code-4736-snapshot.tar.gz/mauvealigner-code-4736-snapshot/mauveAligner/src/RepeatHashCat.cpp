#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "libMems/RepeatHashCat.h"

uint32 gnSequence::concatContigStart( void ) const{
	STACK_TRACE_START
		int32 ccs = this->concat_contig_start;
		return ccs;
	STACK_TRACE_END
}
