#ifndef _MAUVEALIGNER_H

#ifndef __need_getopt
# define _MAUVEALIGNER_H 1
#endif

void print_usage( const char* pname );
int doAlignment( int argc, char* argv[] );

#endif
