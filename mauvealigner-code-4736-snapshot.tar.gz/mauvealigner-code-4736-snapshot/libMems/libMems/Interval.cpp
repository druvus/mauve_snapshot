/*******************************************************************************
 * $Id: Interval.cpp,v 1.12 2004/03/01 02:40:08 darling Exp $
 * This file is copyright 2002-2007 Aaron Darling and authors listed in the AUTHORS file.
 * Please see the file called COPYING for licensing, copying, and modification
 * Please see the file called COPYING for licensing details.
 * **************
 ******************************************************************************/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "libMems/Interval.h"
#include "libMems/gnAlignedSequences.h"
#include "libMems/GappedAlignment.h"
#include "libMems/Match.h"
#include <list>
#include <iterator>

using namespace std;
using namespace genome;
namespace mems {


}
